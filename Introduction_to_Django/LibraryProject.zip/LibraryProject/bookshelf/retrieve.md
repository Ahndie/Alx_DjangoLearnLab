# py command
book = Book.objects.get(id=1)  
print(book)
# Use the ID of the created book
# Expected output <Book: 1984>